﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.IO.Ports;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace serialprogramflash
{
    public partial class Form1 : Form
    {
        //SerialPort serial = new SerialPort();
        public Form1()
        {
            InitializeComponent();
            
            comboBox1.DataSource = SerialPort.GetPortNames();
        }

        private void button1_Click(object sender, EventArgs e) //open
        {
            
            if (!serialPort1.IsOpen)  //시리얼포트가 열려 있지 않으면
            {
                MessageBox.Show("port open");

                serialPort1.PortName = comboBox1.Text;  //콤보박스의 선택된 COM포트명을 시리얼포트명으로 지정
                serialPort1.BaudRate = int.Parse(comboBox2.SelectedItem.ToString());  //보레이트 변경이 필요하면 숫자 변경하기
                serialPort1.DataBits = 8;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Parity = Parity.None;
                // serial = new SerialPort(comboBox1.Text, int.Parse(comboBox2.SelectedText));
                serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialHandler);
                serialPort1.Open();
                serialPort1.DiscardInBuffer();
                richTextBox1.AppendText("com port is opened ");
            }
            else
            {
                MessageBox.Show("port is already opened");
            }
        }

        private void button2_Click(object sender, EventArgs e) // close
        {
            //close
            MessageBox.Show("port closed");
            //SerialPort serial = new SerialPort(comboBox1.Text, 115200);
            //serial.Open();
            //serial.Write("LED3\n\r");
            serialPort1.Close();
        }
        private void serialHandler(object sender, SerialDataReceivedEventArgs e)
        {

            string data = serialPort1.ReadLine();
            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AppendText(data + Environment.NewLine);
                /*
                string[] parts = data.Trim().Split(',');
                //textBox1.AppendText(data + Environment.NewLine);
                //textBox1.Text = data;
                if ((parts.Length == 3) && (int.TryParse(parts[0], out int val1)) && (int.TryParse(parts[1], out int val2)) && (int.TryParse(parts[2], out int val3)))
                //if (int.TryParse(data.Trim(), out int value))
                {
                    sonarvalue = val1;
                    textBox1.Text = val1.ToString();
                    textBox2.Text = val2.ToString();
                    textBox3.Text = val3.ToString();
                    if (val1 >= progressBar1.Minimum && val1 <= progressBar1.Maximum)
                    {
                        progressBar1.Value = val1;
                    }
                    if (val2 / 100 >= progressBar1.Minimum && val2 / 100 <= progressBar1.Maximum)
                    {
                        progressBar2.Value = val2 / 100;
                    }
                    if (val3 / 100 >= progressBar1.Minimum && val3 / 100 <= progressBar1.Maximum)
                    {
                        progressBar3.Value = val3 / 100;
                    }
                }

                _points.Add(index++, sonarvalue);
                //실시간으로 그래프 반영하여 보여주기
                zedGraphControl1.AxisChange();
                zedGraphControl1.Invalidate();
                zedGraphControl1.Refresh();
                */
            });

            }

        private void button3_Click(object sender, EventArgs e)//senddata
        {

            serialPort1.Write(textBox1.Text);
            //textBox2

        }
    }
}
